# Aeterna Backend + Deployment Pack

This pack contains Supabase, Stripe, CI, env, and compliance starter files for the Aeterna website.

## Included

- `supabase/schema.sql` — forms/catalog starter schema with RLS policies
- `stripe/stripe-products.seed.json` — suggested Stripe products/prices
- `.env.example` — environment variables for Vercel/local development
- `.github/workflows/ci.yml` — GitHub Actions typecheck/build workflow
- `LEGAL_COPY_RULES.md` — medical/wellness copy guidelines

## Deployment order

1. Create Supabase project.
2. Run `supabase/schema.sql`.
3. Create Stripe test products/prices from `stripe-products.seed.json`.
4. Add env vars to Vercel.
5. Deploy.
6. Test forms and Stripe Checkout in test mode.
